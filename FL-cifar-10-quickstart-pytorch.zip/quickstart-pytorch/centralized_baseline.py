import argparse
import time
import torch
import torch.nn as nn
from torch.cuda.amp import GradScaler, autocast
from torch.utils.data import DataLoader
from torchvision.datasets import CIFAR10

from pytorchexample.task import (
    Net,
    CIFAR_ROOT,
    pytorch_transforms,
    load_centralized_dataset,
    test,
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--num-workers", type=int, default=4)
    args = parser.parse_args()

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        torch.backends.cudnn.benchmark = True

    # 全量训练集
    train_dataset = CIFAR10(
        root=CIFAR_ROOT,
        train=True,
        download=False,
        transform=pytorch_transforms,
    )

    # 全量测试集
    test_loader = load_centralized_dataset(
        batch_size=args.batch_size,
        num_workers=args.num_workers,
    )

    loader_kwargs = {
        "batch_size": args.batch_size,
        "shuffle": True,
        "num_workers": args.num_workers,
        "pin_memory": torch.cuda.is_available(),
        "persistent_workers": (args.num_workers > 0),
    }
    if args.num_workers > 0:
        loader_kwargs["prefetch_factor"] = 4

    train_loader = DataLoader(train_dataset, **loader_kwargs)

    model = Net().to(device)
    criterion = nn.CrossEntropyLoss().to(device)
    optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9)
    scaler = GradScaler(enabled=(device.type == "cuda"))

    best_acc = -1.0
    best_epoch = -1

    start_time = time.time()

    for epoch in range(1, args.epochs + 1):
        model.train()
        running_loss = 0.0

        for images, labels in train_loader:
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)

            with autocast(enabled=(device.type == "cuda")):
                outputs = model(images)
                loss = criterion(outputs, labels)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()

        avg_train_loss = running_loss / len(train_loader)
        test_loss, test_acc = test(model, test_loader, device)

        if test_acc > best_acc:
            best_acc = test_acc
            best_epoch = epoch
            torch.save(model.state_dict(), "centralized_best_model.pt")

        print(
            f"Epoch {epoch:03d} | "
            f"train_loss={avg_train_loss:.4f} | "
            f"test_loss={test_loss:.4f} | "
            f"test_acc={test_acc:.4f}"
        )

    total_time = time.time() - start_time
    torch.save(model.state_dict(), "centralized_final_model.pt")

    print("\nTraining finished.")
    print(f"Best acc = {best_acc:.4f} at epoch {best_epoch}")
    print(f"Total time = {total_time:.2f}s")


if __name__ == "__main__":
    main()