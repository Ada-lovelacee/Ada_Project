# """pytorchexample: A Flower / PyTorch app."""

# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# from datasets import load_dataset
# from flwr_datasets import FederatedDataset
# from flwr_datasets.partitioner import IidPartitioner
# from torch.utils.data import DataLoader
# from torchvision.transforms import Compose, Normalize, ToTensor


# class Net(nn.Module):
#     """Model (simple CNN adapted from 'PyTorch: A 60 Minute Blitz')"""

#     def __init__(self):
#         super(Net, self).__init__()
#         self.conv1 = nn.Conv2d(3, 6, 5)
#         self.pool = nn.MaxPool2d(2, 2)
#         self.conv2 = nn.Conv2d(6, 16, 5)
#         self.fc1 = nn.Linear(16 * 5 * 5, 120)
#         self.fc2 = nn.Linear(120, 84)
#         self.fc3 = nn.Linear(84, 10)

#     def forward(self, x):
#         x = self.pool(F.relu(self.conv1(x)))
#         x = self.pool(F.relu(self.conv2(x)))
#         x = x.view(-1, 16 * 5 * 5)
#         x = F.relu(self.fc1(x))
#         x = F.relu(self.fc2(x))
#         return self.fc3(x)


# fds = None  # Cache FederatedDataset

# pytorch_transforms = Compose([ToTensor(), Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])


# def apply_transforms(batch):
#     """Apply transforms to the partition from FederatedDataset."""
#     batch["img"] = [pytorch_transforms(img) for img in batch["img"]]
#     return batch


# def load_data(partition_id: int, num_partitions: int, batch_size: int):
#     """Load partition CIFAR10 data."""
#     # Only initialize `FederatedDataset` once
#     global fds
#     if fds is None:
#         partitioner = IidPartitioner(num_partitions=num_partitions)
#         fds = FederatedDataset(
#             dataset="uoft-cs/cifar10",
#             partitioners={"train": partitioner},
#         )
#     partition = fds.load_partition(partition_id)
#     # Divide data on each node: 80% train, 20% test
#     partition_train_test = partition.train_test_split(test_size=0.2, seed=42)
#     # Construct dataloaders
#     partition_train_test = partition_train_test.with_transform(apply_transforms)
#     trainloader = DataLoader(
#         partition_train_test["train"], batch_size=batch_size, shuffle=True
#     )
#     testloader = DataLoader(partition_train_test["test"], batch_size=batch_size)
#     return trainloader, testloader


# def load_centralized_dataset():
#     """Load test set and return dataloader."""
#     # Load entire test set
#     test_dataset = load_dataset("uoft-cs/cifar10", split="test")
#     dataset = test_dataset.with_format("torch").with_transform(apply_transforms)
#     return DataLoader(dataset, batch_size=128)


# def train(net, trainloader, epochs, lr, device):
#     """Train the model on the training set."""
#     net.to(device)  # move model to GPU if available
#     criterion = torch.nn.CrossEntropyLoss().to(device)
#     optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=0.9)
#     net.train()
#     running_loss = 0.0
#     for _ in range(epochs):
#         for batch in trainloader:
#             images = batch["img"].to(device)
#             labels = batch["label"].to(device)
#             optimizer.zero_grad()
#             loss = criterion(net(images), labels)
#             loss.backward()
#             optimizer.step()
#             running_loss += loss.item()
#     avg_trainloss = running_loss / (epochs * len(trainloader))
#     return avg_trainloss


# def test(net, testloader, device):
#     """Validate the model on the test set."""
#     net.to(device)
#     criterion = torch.nn.CrossEntropyLoss()
#     correct, loss = 0, 0.0
#     with torch.no_grad():
#         for batch in testloader:
#             images = batch["img"].to(device)
#             labels = batch["label"].to(device)
#             outputs = net(images)
#             loss += criterion(outputs, labels).item()
#             correct += (torch.max(outputs.data, 1)[1] == labels).sum().item()
#     accuracy = correct / len(testloader.dataset)
#     loss = loss / len(testloader)
#     return loss, accuracy
# """pytorchexample: A Flower / PyTorch app (local CIFAR-10 version)."""

# import numpy as np
# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# from torch.utils.data import DataLoader, Subset
# from torchvision.datasets import CIFAR10
# from torchvision.transforms import Compose, Normalize, ToTensor


# class Net(nn.Module):
#     """Model (simple CNN adapted from 'PyTorch: A 60 Minute Blitz')."""

#     def __init__(self):
#         super(Net, self).__init__()
#         self.conv1 = nn.Conv2d(3, 6, 5)
#         self.pool = nn.MaxPool2d(2, 2)
#         self.conv2 = nn.Conv2d(6, 16, 5)
#         self.fc1 = nn.Linear(16 * 5 * 5, 120)
#         self.fc2 = nn.Linear(120, 84)
#         self.fc3 = nn.Linear(84, 10)

#     def forward(self, x):
#         x = self.pool(F.relu(self.conv1(x)))
#         x = self.pool(F.relu(self.conv2(x)))
#         x = x.view(-1, 16 * 5 * 5)
#         x = F.relu(self.fc1(x))
#         x = F.relu(self.fc2(x))
#         return self.fc3(x)


# # 改成你的本地 CIFAR-10 根目录
# CIFAR_ROOT = "/root/autodl-tmp/cifar10"

# pytorch_transforms = Compose(
#     [ToTensor(), Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]
# )


# def load_data(partition_id: int, num_partitions: int, batch_size: int):
#     """Load local CIFAR-10 and split it into IID partitions."""
#     trainset = CIFAR10(
#         root=CIFAR_ROOT,
#         train=True,
#         download=False,
#         transform=pytorch_transforms,
#     )

#     # 把完整训练集按客户端数平均切分
#     all_indices = np.arange(len(trainset))
#     partition_indices = np.array_split(all_indices, num_partitions)[partition_id]

#     # 为了更稳一点，先打乱，再做 80/20 train-test split
#     rng = np.random.default_rng(seed=42 + partition_id)
#     partition_indices = rng.permutation(partition_indices)

#     split_idx = int(0.8 * len(partition_indices))
#     train_indices = partition_indices[:split_idx]
#     test_indices = partition_indices[split_idx:]

#     train_subset = Subset(trainset, train_indices.tolist())
#     test_subset = Subset(trainset, test_indices.tolist())

#     trainloader = DataLoader(
#         train_subset,
#         batch_size=batch_size,
#         shuffle=True,
#         num_workers=2,
#         pin_memory=torch.cuda.is_available(),
#     )
#     testloader = DataLoader(
#         test_subset,
#         batch_size=batch_size,
#         shuffle=False,
#         num_workers=2,
#         pin_memory=torch.cuda.is_available(),
#     )
#     return trainloader, testloader


# def load_centralized_dataset():
#     """Load the full local CIFAR-10 test set and return dataloader."""
#     test_dataset = CIFAR10(
#         root=CIFAR_ROOT,
#         train=False,
#         download=False,
#         transform=pytorch_transforms,
#     )
#     return DataLoader(
#         test_dataset,
#         batch_size=128,
#         shuffle=False,
#         num_workers=2,
#         pin_memory=torch.cuda.is_available(),
#     )


# def train(net, trainloader, epochs, lr, device):
#     """Train the model on the training set."""
#     net.to(device)
#     criterion = torch.nn.CrossEntropyLoss().to(device)
#     optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=0.9)
#     net.train()
#     running_loss = 0.0

#     for _ in range(epochs):
#         for images, labels in trainloader:
#             images = images.to(device)
#             labels = labels.to(device)

#             optimizer.zero_grad()
#             loss = criterion(net(images), labels)
#             loss.backward()
#             optimizer.step()
#             running_loss += loss.item()

#     avg_trainloss = running_loss / (epochs * len(trainloader))
#     return avg_trainloss


# def test(net, testloader, device):
#     """Validate the model on the test set."""
#     net.to(device)
#     criterion = torch.nn.CrossEntropyLoss().to(device)
#     correct, loss = 0, 0.0
#     net.eval()

#     with torch.no_grad():
#         for images, labels in testloader:
#             images = images.to(device)
#             labels = labels.to(device)

#             outputs = net(images)
#             loss += criterion(outputs, labels).item()
#             correct += (torch.max(outputs.data, 1)[1] == labels).sum().item()

#     accuracy = correct / len(testloader.dataset)
#     loss = loss / len(testloader)
#     return loss, accuracy
"""pytorchexample: A Flower / PyTorch app (local CIFAR-10 version)."""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.cuda.amp import GradScaler, autocast
from torch.utils.data import DataLoader, Subset
from torchvision.datasets import CIFAR10
from torchvision.transforms import Compose, Normalize, ToTensor


class Net(nn.Module):
    """Simple CNN for CIFAR-10."""

    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 16 * 5 * 5)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)


# 本地 CIFAR-10 根目录
CIFAR_ROOT = "/root/autodl-tmp/cifar10"

pytorch_transforms = Compose(
    [ToTensor(), Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))]
)

_DEVICE_INFO_PRINTED = False

if torch.cuda.is_available():
    torch.backends.cudnn.benchmark = True


def log_device_once(device: torch.device):
    """Print device info once."""
    global _DEVICE_INFO_PRINTED
    if _DEVICE_INFO_PRINTED:
        return

    if device.type == "cuda":
        gpu_index = device.index if device.index is not None else 0
        print(f"[task.py] Using device: {device}")
        print(f"[task.py] GPU: {torch.cuda.get_device_name(gpu_index)}")
    else:
        print(f"[task.py] Using device: {device}")

    _DEVICE_INFO_PRINTED = True


def _make_iid_partition(trainset, partition_id: int, num_partitions: int):
    """Create IID-like partition by globally shuffling then splitting."""
    rng = np.random.default_rng(seed=2025)
    all_indices = rng.permutation(len(trainset))
    return np.array_split(all_indices, num_partitions)[partition_id]


def _make_noniid_partition(trainset, partition_id: int, num_partitions: int):
    """
    Pathological non-IID split:
    Sort by label, split into 2*num_partitions shards,
    each client gets 2 shards, so label distribution is skewed.
    """
    targets = np.array(trainset.targets)
    indices = np.arange(len(trainset))
    sorted_indices = indices[np.argsort(targets)]

    num_shards = num_partitions * 2
    shards = np.array_split(sorted_indices, num_shards)

    rng = np.random.default_rng(seed=2025)
    shard_order = rng.permutation(num_shards)

    assigned = shard_order[2 * partition_id: 2 * partition_id + 2]
    part = np.concatenate([shards[i] for i in assigned])
    return part


def load_data(
    partition_id: int,
    num_partitions: int,
    batch_size: int,
    partition_mode: str = "iid",
    num_workers: int = 4,
):
    """Load local CIFAR-10 and split into client train/val loaders."""
    trainset = CIFAR10(
        root=CIFAR_ROOT,
        train=True,
        download=False,
        transform=pytorch_transforms,
    )

    if partition_mode == "noniid":
        partition_indices = _make_noniid_partition(
            trainset, partition_id, num_partitions
        )
    else:
        partition_indices = _make_iid_partition(
            trainset, partition_id, num_partitions
        )

    # 每个客户端再做本地 80/20 train-val split
    rng = np.random.default_rng(seed=42 + partition_id)
    partition_indices = rng.permutation(partition_indices)

    split_idx = int(0.8 * len(partition_indices))
    train_indices = partition_indices[:split_idx]
    val_indices = partition_indices[split_idx:]

    train_subset = Subset(trainset, train_indices.tolist())
    val_subset = Subset(trainset, val_indices.tolist())

    use_cuda = torch.cuda.is_available()

    loader_kwargs = {
        "batch_size": batch_size,
        "num_workers": num_workers,
        "pin_memory": use_cuda,
        "persistent_workers": (num_workers > 0),
    }
    if num_workers > 0:
        loader_kwargs["prefetch_factor"] = 4

    trainloader = DataLoader(
        train_subset,
        shuffle=True,
        **loader_kwargs,
    )
    valloader = DataLoader(
        val_subset,
        shuffle=False,
        **loader_kwargs,
    )
    return trainloader, valloader


def load_centralized_dataset(batch_size: int = 256, num_workers: int = 4):
    """Load full CIFAR-10 test set."""
    test_dataset = CIFAR10(
        root=CIFAR_ROOT,
        train=False,
        download=False,
        transform=pytorch_transforms,
    )

    use_cuda = torch.cuda.is_available()

    loader_kwargs = {
        "batch_size": batch_size,
        "shuffle": False,
        "num_workers": num_workers,
        "pin_memory": use_cuda,
        "persistent_workers": (num_workers > 0),
    }
    if num_workers > 0:
        loader_kwargs["prefetch_factor"] = 4

    return DataLoader(test_dataset, **loader_kwargs)


def train(net, trainloader, epochs, lr, device):
    """Train the model on the training set."""
    log_device_once(device)

    net.to(device)
    criterion = nn.CrossEntropyLoss().to(device)
    optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=0.9)
    scaler = GradScaler(enabled=(device.type == "cuda"))

    net.train()
    running_loss = 0.0

    for _ in range(epochs):
        for images, labels in trainloader:
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)

            with autocast(enabled=(device.type == "cuda")):
                outputs = net(images)
                loss = criterion(outputs, labels)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()

    avg_trainloss = running_loss / (epochs * len(trainloader))
    return float(avg_trainloss)


def test(net, testloader, device):
    """Validate the model on the test set."""
    log_device_once(device)

    net.to(device)
    criterion = nn.CrossEntropyLoss().to(device)
    correct = 0
    loss = 0.0
    net.eval()

    with torch.no_grad():
        for images, labels in testloader:
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)

            with autocast(enabled=(device.type == "cuda")):
                outputs = net(images)
                batch_loss = criterion(outputs, labels)

            loss += batch_loss.item()
            correct += (outputs.argmax(dim=1) == labels).sum().item()

    accuracy = correct / len(testloader.dataset)
    loss = loss / len(testloader)
    return float(loss), float(accuracy)